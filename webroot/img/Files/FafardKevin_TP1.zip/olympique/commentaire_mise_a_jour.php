<?php
// Connexion à la base de données
try {
    $bdd = new PDO('mysql:host=localhost;dbname=Olympique;charset=utf8', 'root', 'mysql');
} catch (Exception $e) {
    die('Erreur : ' . $e->getMessage());
}
$Paralympics = (isset($_POST['Paralympics'])) ? 1 : 0;
// Insertion du commentaire à l'aide d'une requête préparée
$req = $bdd->prepare('UPDATE Results SET Competitor_ID = ?, Colour_Name = ?, Sport_Code = ?, Event_ID = ?, Results_Details = ?, Paralympics = ? WHERE Results_ID = ?');
$req->execute(array($_POST['Competitor_ID'], $_POST['Colour_Name'], $_POST['Sport_Code'], $_POST['Event_ID'], $_POST['Results_Details'], $Paralympics, $_POST['Results_ID']));

// Redirection du visiteur vers la page d'accueil du Blogue
// En commentaire si déboguage
header('Location: index.php');
?>
<!-- Pour déboguage 
<html>
    <body>
		<h2>Mettre à jour un compétiteur</h2>
        <form action="index.php">
            *** Pour déboguage ***<br />
            Voici le contenu de $_POST envoyé par le formulaire de modification et transmis à la requête : <br />
            <?php var_dump($_POST); ?>
            <input type="submit" value="Continuer">
        </form>
    </body>     
</html>
-->
