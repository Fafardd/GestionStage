-- phpMyAdmin SQL Dump
-- version 4.4.15.9
-- https://www.phpmyadmin.net
--
-- Client :  localhost
-- Généré le :  Mar 27 Février 2018 à 15:23
-- Version du serveur :  5.6.37
-- Version de PHP :  5.6.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `Olympique`
--

-- --------------------------------------------------------

--
-- Structure de la table `Competitors`
--

CREATE TABLE IF NOT EXISTS `Competitors` (
  `Competitor_ID` int(11) NOT NULL,
  `Country_Code` int(11) NOT NULL,
  `Gender_Code` int(11) NOT NULL,
  `Date_of_Birth` date NOT NULL,
  `First_Name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `Last_Name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `Other_Details` varchar(255) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `Medals`
--

CREATE TABLE IF NOT EXISTS `Medals` (
  `Colour_Name` varchar(255) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `Results`
--

CREATE TABLE IF NOT EXISTS `Results` (
  `Results_ID` int(11) NOT NULL,
  `Competitor_ID` int(11) NOT NULL,
  `Event_ID` int(11) NOT NULL,
  `Sport_Code` int(11) NOT NULL,
  `Colour_Name` varchar(255) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `Sports`
--

CREATE TABLE IF NOT EXISTS `Sports` (
  `Sport_Code` int(11) NOT NULL,
  `Sport_Description` varchar(255) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Index pour les tables exportées
--

--
-- Index pour la table `Competitors`
--
ALTER TABLE `Competitors`
  ADD PRIMARY KEY (`Competitor_ID`);

--
-- Index pour la table `Medals`
--
ALTER TABLE `Medals`
  ADD PRIMARY KEY (`Colour_Name`);

--
-- Index pour la table `Results`
--
ALTER TABLE `Results`
  ADD PRIMARY KEY (`Results_ID`),
  ADD KEY `Results_ID` (`Results_ID`,`Competitor_ID`,`Event_ID`,`Sport_Code`,`Colour_Name`),
  ADD KEY `Competitor_ID` (`Competitor_ID`),
  ADD KEY `Colour_Name` (`Colour_Name`),
  ADD KEY `Sport_Code` (`Sport_Code`);

--
-- Index pour la table `Sports`
--
ALTER TABLE `Sports`
  ADD PRIMARY KEY (`Sport_Code`);

--
-- AUTO_INCREMENT pour les tables exportées
--

--
-- AUTO_INCREMENT pour la table `Competitors`
--
ALTER TABLE `Competitors`
  MODIFY `Competitor_ID` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `Results`
--
ALTER TABLE `Results`
  MODIFY `Results_ID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=14;
--
-- AUTO_INCREMENT pour la table `Sports`
--
ALTER TABLE `Sports`
  MODIFY `Sport_Code` int(11) NOT NULL AUTO_INCREMENT;
--
-- Contraintes pour les tables exportées
--

--
-- Contraintes pour la table `Results`
--
ALTER TABLE `Results`
  ADD CONSTRAINT `results_ibfk_1` FOREIGN KEY (`Competitor_ID`) REFERENCES `Competitors` (`Competitor_ID`),
  ADD CONSTRAINT `results_ibfk_2` FOREIGN KEY (`Colour_Name`) REFERENCES `Medals` (`Colour_Name`),
  ADD CONSTRAINT `results_ibfk_3` FOREIGN KEY (`Sport_Code`) REFERENCES `Sports` (`Sport_Code`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
