<?php
// Connexion à la base de données
try {
    $bdd = new PDO('mysql:host=localhost;dbname=Olympique;charset=utf8', 'root', 'mysql');
} catch (Exception $e) {
    die('Erreur : ' . $e->getMessage());
}
$Paralympics = (isset($_POST['Paralympics'])) ? 1 : 0;
// Insertion du commentaire à l'aide d'une requête préparée
$req = $bdd->prepare('INSERT INTO Results (Competitor_ID, Colour_Name, Sport_Code, Event_ID, Results_Details, Paralympics) VALUES(?,?, ?, ?, ?, ?)');
$req->execute(array($_POST['Competitor_ID'], $_POST['Colour_Name'], $_POST['Sport_Code'], $_POST['Event_ID'], $_POST['Results_Details'], $Paralympics));

// Redirection du visiteur vers la page d'accueil
// En commentaire si déboguage
header('Location: index.php');
?>
<!--
<html>
    <body>
		<!-- Ce bout de code HTML peut-être réutilisé n'importe où au besoin ---
		--- Seule l'action de la balise Form ci-dessous doit être adaptée au contexte ---
		--- Notez la différence dans l'affichage de "print_r" et de "var_dump" ---
		--- elle est due à la présence de l'extension "xdebug" dans l'environnement php de Ampps (cf. phpinfo) ---
		--- sinon l'affichage serait identique --- 
		--- comme xdebug est souvent présent dans les environnements de développement PHP, "var_dump" est préféré --><!--
		<h2>Envoyer un compétiteur </h2>
	     *** Pour déboguage ***<br />
		Voici le contenu de $_POST envoyé par le formulaire d'envoi et transmis à la requête : <br />
        <?php var_dump($_POST); ?>
        <?php // print_r($_POST); // décommentez pour comparer avec var_dump ?>
        <form action="index.php">
            <input type="submit" value="Continuer">
        </form>
    </body>     
</html>-->
