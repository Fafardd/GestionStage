<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8" />
        <title>Supprimer un compétiteur</title>
    </head>
    <style>
        form
        {
            text-align:center;
        }
    </style>
    <body>


        <?php
// Connexion à la base de données
        try {
            $bdd = new PDO('mysql:host=localhost;dbname=Olympique;charset=utf8', 'root', 'mysql');
        } catch (Exception $e) {
            die('Erreur : ' . $e->getMessage());
        }

// Récupération du message à modifier
        $reponse = $bdd->query('SELECT * FROM Results WHERE Results_ID = ' . $_GET['Results_ID']);

// Affichage du message à modifer (toutes les données externes sont protégées par htmlspecialchars)
        $donnees = $reponse->fetch();
        $reponse->closeCursor();
        ?>


        <form action="supprimer2.php" method="post">
			<h2>Voulez-vous vraiment supprimer ce compétiteur ?</h2>
            <p>
                <label for="Competitor_ID">ID du compétiteur</label> : <input type="text" name="Competitor_ID" id="Competitor_ID" value="<?php echo htmlspecialchars($donnees['Competitor_ID']); ?>" /><br />
                <label for="Colour_Name">Couleur de la médaille</label> :  <input type="text" name="Colour_Name" id="Colour_Name" value="<?php echo htmlspecialchars($donnees['Colour_Name']); ?>" /><br />
				<label for="Sport_Code">Code du sport</label> :  <input type="text" name="Sport_Code" id="Sport_Code" value="<?php echo htmlspecialchars($donnees['Sport_Code']); ?>" /><br />
				<label for="Event_ID">Numéro de l'évènement</label> :  <input type="text" name="Event_ID" id="Event_ID" value="<?php echo htmlspecialchars($donnees['Event_ID']); ?>" /><br />
				<label for="Results_Details">Info</label> :  <textarea type="text" name="Results_Details" id="Results_Details" ><?php echo htmlspecialchars($donnees['Results_Details']); ?></textarea><br />
				<label for="Paralympics">Paralympiques</label> :  <input type="checkbox" name="Paralympics" <?php echo $donnees['Paralympics'] == 1 ? 'checked="checked"' : '' ; ?>/><br />
				<input type="hidden" name="Results_ID" value="<?php echo $donnees['Results_ID']; ?>" />
                <input type="submit" value="Supprimer" />
            </p>
        </form>
    </body>
</html>