<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8" />
        <title>Envoi de commentaires</title>
    </head>
    <style>
    form
    {
        text-align:center;
    }
    </style>
    <body>
    
    <form action="commentaire_envoyer.php" method="post">
		<h2>Ajouter un compétiteur</h2>
		<p><a href="apropos.html">À propos</a></p>
        <p>
        <label for="Competitor_ID">Numéro du compétiteur</label> : <input type="text" name="Competitor_ID" id="Competitor_ID" /><br />
        <label for="Colour_Name">Couleur de la médaille</label> :  <input type="text" name="Colour_Name" id="Colour_Name" /><br />
        <label for="Sport_Code">Code du sport</label> :  <input type="text" name="Sport_Code" id="Sport_Code" /><br />
		<label for="Event_ID">Code de l'évènement</label> :  <input type="text" name="Event_ID" id="Event_ID" /><br />
		<label for="Results_Details">Informations pertinantes</label> :  <textarea type="text" name="Results_Details" id="Results_Details" >Écrivez votre commentaire ici</textarea><br />
		<label for="Paralympics">Paralympiques</label> :  <input type="checkbox" name="Paralympics" id="Paralympics" />
        <input type="submit" value="Envoyer" />
	</p>
    </form>
	
<table>
<?php
// Connexion à la base de données
try
{
	$bdd = new PDO('mysql:host=localhost;dbname=Olympique;charset=utf8', 'root', 'mysql');
}
catch(Exception $e)
{
        die('Erreur : '.$e->getMessage());
}

// Récupération des 10 derniers commentaires
$reponse = $bdd->query('SELECT * FROM Results');

// Affichage de chaque commentaire (toutes les données sont protégées par htmlspecialchars)
?>
<table>
<?php
while ($donnees = $reponse->fetch())
{?>
<tr>
<td>
	
	<?php
		echo '<p><a href="supprimer.php?Results_ID=' .$donnees['Results_ID'] . '">[supprimer]</a>
		<a href="commentaire_modifier.php?Results_ID=' . $donnees['Results_ID'] . '">[modifier]</a> <strong> Numéro du compétiteur : </strong> ' . 
		htmlspecialchars($donnees['Competitor_ID']) . 
		',<strong> Couleur de la médaille : </strong> ' . 
		htmlspecialchars($donnees['Colour_Name']) . ', <strong> Code du sport : </strong> ' . 
		htmlspecialchars($donnees['Sport_Code']) . ", <strong> Code de l'évènement : </strong> " . 
		htmlspecialchars($donnees['Event_ID']) . ' , <strong> Informations pertinantes : </strong> ' .
		htmlspecialchars($donnees['Results_Details']) . 
		'<strong> (Paralympiques : </strong> ' . htmlspecialchars($donnees['Paralympics'] == 1 ? "Oui" : "Non") .
		')</p>';
		?>
		</td>
		</tr>
		<?php
}


$reponse->closeCursor();

?>
</table>
    </body>
</html>

